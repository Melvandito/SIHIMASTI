	  <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b> <?= Yii::powered()?> </b>
        </div>
        <strong>Copyright &copy; 2017 <a href="http://almsaeedstudio.com">TI-02-MPPL-ITDel</a></strong>
      </footer>