<?php

use adminlte\widgets\Menu;
use yii\helpers\Html;
use yii\helpers\Url;
?>
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
    
        <?=Menu::widget(
                [
                    'options' => ['class' => 'sidebar-menu'],
                    'items' => [
                        //['label' => 'Menu', 'options' => ['class' => 'header']],
                        ['label' => 'Home', 'icon' => 'fa fa-dashboard', 
                            'url' => ['/'], 'active' => $this->context->route == 'site/index'
                        ],
                        [
                            'label' => 'Master',
                            'icon' => 'fa fa-database',
                            'url' => '#',
                            'items' => [
                                [
                                    'label' => 'Master1',
                                    'icon' => 'fa fa-database',
                                    'url' => '?r=master1/',				    
                                ],
                                [
                                    'label' => 'Master2',
                                    'icon' => 'fa fa-database',
                                    'url' => '?r=master2/',				    
                                ]
                            ]
                        ],
                        [
                            'label' => 'Announcement',
                            'icon' => 'fa fa-bullhorn',
                            'url' => ['/announcement/index'],
                            
                        ],
                        [
                            'label' => 'Members',
                            'icon' => 'fa fa-users',
                            'url' => ['/member/index'],
                            
                        ],
                        [
                            'label' => 'Finances',
                            'icon' => 'fa fa-dollar',
                            'url' => ['/finances/index'],
                            
                        ],
                        [
                            'label' => 'Voting',
                            'icon' => 'fa fa-bar-chart-o',
                            'url' => ['/voting/index'],
                        ],
                        [
                            'label' => 'Gallery',
                            'icon' => 'fa fa-newspaper-o',
                            'url' => ['/gallery'],
                        ],
                        [
                            'label' => 'Tutorial',
                            'icon' => 'fa fa-caret-square-o-right',
                            'url' => ['/tutorial/index'],
                        ],
                        [
                            'label' => 'Rules and SOP',
                            'icon' => 'fa fa-link',
                            'url' => ['/rule/index'],
                        ],
                    ],
                ]
        )
        ?>
        
    </section>
    <!-- /.sidebar -->
</aside>
