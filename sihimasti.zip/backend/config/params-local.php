<?php
Yii::setAlias('@filelocation','http://localhost/sihimasti1/backend/web/files/announcement/'); 
return [
];
