<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "tutorial".
 *
 * @property integer $id
 * @property string $mata_kuliah
 * @property string $topik
 * @property string $tutor
 * @property string $lokasi
 * @property string $tanggal_pelaksanaan
 * @property string $created_date
 * @property string $updated_date
 * @property integer $id_user
 * @property string $keterangan
 */
class Tutorial extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tutorial';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['mata_kuliah', 'topik', 'tutor', 'lokasi', 'tanggal_pelaksanaan', 'created_date', 'updated_date', 'keterangan'], 'required'],
            [['tanggal_pelaksanaan', 'created_date', 'updated_date'], 'safe'],
            [['id_user'], 'integer'],
            [['keterangan'], 'string'],
            [['mata_kuliah', 'topik', 'tutor', 'lokasi'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'mata_kuliah' => 'Mata Kuliah',
            'topik' => 'Topik',
            'tutor' => 'Tutor',
            'lokasi' => 'Lokasi',
            'tanggal_pelaksanaan' => 'Tanggal Pelaksanaan',
            'created_date' => 'Created Date',
            'updated_date' => 'Updated Date',
            'id_user' => 'Id User',
            'keterangan' => 'Keterangan',
        ];
    }
}
